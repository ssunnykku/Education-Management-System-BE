package com.kosta.ems.scholarship;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScholarshipSettlementResultDTO {

    private String studentId;
    private String hrdNetId;
    private String name;
    private String bank;
    private String account;
    private String managerId;
    private char isActive;
    private Long studentCourseSeq;
    private Long courseSeq;
    private int courseNumber;
    private String courseName;
    private LocalDate scholarshipDate;
    private int scholarshipAmount;
}
