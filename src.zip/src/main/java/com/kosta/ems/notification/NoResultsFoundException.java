package com.kosta.ems.notification;

public class NoResultsFoundException extends Exception {

	public NoResultsFoundException(String message) {
		super(message);
	}
}
